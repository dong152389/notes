/*
 Navicat Premium Data Transfer

 Source Server         : 192.168.25.10_3306
 Source Server Type    : MySQL
 Source Server Version : 80027 (8.0.27)
 Source Host           : 192.168.25.10:3306
 Source Schema         : rocketmq

 Target Server Type    : MySQL
 Target Server Version : 80027 (8.0.27)
 File Encoding         : 65001

 Date: 08/02/2023 17:44:59
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for mq_record
-- ----------------------------
DROP TABLE IF EXISTS `mq_record`;
CREATE TABLE `mq_record`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `msg_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '消息的唯一ID',
  `send_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '发送状态',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '消息内容',
  `topic` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '消息主题',
  `tag` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '消息标签',
  `create_time` datetime NOT NULL COMMENT '消息创建时间',
  `business_id` bigint NOT NULL COMMENT '业务ID',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `msg_id`(`msg_id` ASC) USING BTREE COMMENT '唯一性索引',
  INDEX `msg_id_2`(`msg_id` ASC, `content` ASC, `business_id` ASC) USING BTREE COMMENT '普通索引',
  CONSTRAINT `mq_record_ibfk_1` FOREIGN KEY (`msg_id`) REFERENCES `mq_record` (`msg_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of mq_record
-- ----------------------------
INSERT INTO `mq_record` VALUES (3, '0AC89BDA4E2818B4AAC2273A52C20000', 'SEND_OK', '煞笔', 'TestTopic', 'TestTag', '2023-02-08 14:48:54', 1623212251128893440);
INSERT INTO `mq_record` VALUES (4, '0AC89BDA5A3418B4AAC2275298480000', 'SEND_OK', '煞笔', 'TestTopic', 'TestTag', '2023-02-08 15:15:24', 1623218922626510848);
INSERT INTO `mq_record` VALUES (5, '0AC89BDA5A3418B4AAC2275343AA0001', 'SEND_OK', '煞笔', 'TestTopic', 'aa', '2023-02-08 15:16:08', 1623219109163986944);
INSERT INTO `mq_record` VALUES (6, '0AC89BDA5D2018B4AAC227B4FB0E0000', 'SEND_OK', '煞笔', 'TestTopic', 'aa', '2023-02-08 17:02:52', 1623245965682614272);
INSERT INTO `mq_record` VALUES (7, '0AC89BDA5D2018B4AAC227B8DAE00001', 'SEND_OK', '阿萨德', 'TestTopic', 'aa', '2023-02-08 17:07:06', 1623247034194141184);
INSERT INTO `mq_record` VALUES (8, '0AC89BDA5D2018B4AAC227BD3C390002', 'SEND_OK', '阿萨德', 'TestTopic', 'aa', '2023-02-08 17:11:53', 1623248238227824640);

-- ----------------------------
-- Table structure for mq_topic
-- ----------------------------
DROP TABLE IF EXISTS `mq_topic`;
CREATE TABLE `mq_topic`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `msg_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '消息的唯一ID',
  `business_id` bigint NOT NULL COMMENT '业务ID',
  `topic` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '消息主题',
  `tag` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '消息标签',
  `status` tinyint NOT NULL COMMENT '0 是未消费，1 是消费',
  `consume_time` datetime NULL DEFAULT NULL COMMENT '消费时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `msg_id`(`msg_id` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of mq_topic
-- ----------------------------

SET FOREIGN_KEY_CHECKS = 1;
