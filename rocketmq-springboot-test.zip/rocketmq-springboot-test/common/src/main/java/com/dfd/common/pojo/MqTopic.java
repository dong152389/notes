package com.dfd.common.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Builder;
import lombok.Data;

import java.util.Date;

/**
 * @Author: Fengdong.Duan
 * @Date: 2023/2/8 14:57
 */
@Data
@Builder
@TableName(value = "mq_topic")
public class MqTopic {
    public static final String COL_PRODUCER_ID = "producer_id";
    public static final String COL_CONSUMER_ID = "consumer_id";
    public static final String COL_CREATE_TIME = "create_time";
    /**
     * 自增ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 消息的唯一ID
     */
    @TableField(value = "msg_id")
    private String msgId;

    /**
     * 业务ID
     */
    @TableField(value = "business_id")
    private Long businessId;

    /**
     * 消息主题
     */
    @TableField(value = "topic")
    private String topic;

    /**
     * 消息标签
     */
    @TableField(value = "tag")
    private String tag;

    /**
     * 0 是未消费，1 是消费
     */
    @TableField(value = "`status`")
    private Byte status;

    /**
     * 消费时间
     */
    @TableField(value = "consume_time")
    private Date consumeTime;

    public static final String COL_ID = "id";

    public static final String COL_MSG_ID = "msg_id";

    public static final String COL_BUSINESS_ID = "business_id";

    public static final String COL_TOPIC = "topic";

    public static final String COL_TAG = "tag";

    public static final String COL_STATUS = "status";

    public static final String COL_CONSUME_TIME = "consume_time";
}
