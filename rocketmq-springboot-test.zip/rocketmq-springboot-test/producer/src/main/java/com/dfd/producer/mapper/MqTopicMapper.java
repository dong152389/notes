package com.dfd.producer.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dfd.common.pojo.MqTopic;

/**
 * @Author: Fengdong.Duan
 * @Date: 2023/2/8 14:57
 */
public interface MqTopicMapper extends BaseMapper<MqTopic> {
}
