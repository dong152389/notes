package com.dfd.producer.controller;

import com.dfd.common.pojo.MqRecord;
import com.dfd.common.pojo.MqTopic;
import com.dfd.common.utils.IdWorker;
import com.dfd.producer.service.MqRecordService;
import com.dfd.producer.service.MqTopicService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.rocketmq.client.producer.DefaultMQProducer;
import org.apache.rocketmq.client.producer.SendResult;
import org.apache.rocketmq.common.message.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * Created on 2021/12/21.
 *
 * @author DD
 */
@Slf4j
@RestController
@RequestMapping("/mqProducer")
public class MQProducerController {
    public static final Logger LOGGER = LoggerFactory.getLogger(MQProducerController.class);

    @Autowired
    DefaultMQProducer defaultMQProducer;
    @Autowired
    MqRecordService mqRecordService;
    @Autowired
    MqTopicService mqTopicService;

    @Autowired


    /**
     * 发送简单的MQ消息
     *
     * @param msg
     * @return
     */
    @GetMapping("/send")
    public ResponseEntity<SendResult> send(String msg) {
        try {

            SendResult sendResult = null;
            if (StringUtils.isEmpty(msg)) {
                return ResponseEntity.status(500).body(sendResult);
            }
            LOGGER.info("发送MQ消息内容：" + msg);
            //执行业务
            //.......
            //执行结束
            Long l = new IdWorker().nextId();
            String topic = "TestTopic";
            String tags = "aa";
            Message sendMsg = new Message(topic, tags, l + "", msg.getBytes());
            // 默认3秒超时
            sendResult = defaultMQProducer.send(sendMsg);

            //存入mysql
            MqRecord record = MqRecord.builder()
                    .msgId(sendResult.getMsgId())
                    .sendStatus(sendResult.getSendStatus().name())
                    .content(msg)
                    .topic(topic)
                    .tag(tags)
                    .businessId(l)
                    .createTime(new Date()).build();
            MqTopic mqTopic = MqTopic.builder().status((byte) 0).topic(topic).tag(tags).businessId(l).msgId(sendResult.getMsgId()).build();
            mqRecordService.save(record);
            mqTopicService.save(mqTopic);


            LOGGER.info("消息发送响应：" + sendResult.toString());
            return ResponseEntity.ok(sendResult);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }
}
