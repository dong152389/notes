package com.dfd.consumer.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dfd.common.pojo.MqRecord;
import com.dfd.consumer.mapper.MqRecordMapper;
import com.dfd.consumer.service.MqRecordService;
import org.springframework.stereotype.Service;
/**
* @Author: Fengdong.Duan
* @Date: 2023/2/8 10:25
*/
@Service
public class MqRecordServiceImpl extends ServiceImpl<MqRecordMapper, MqRecord> implements MqRecordService {

}
