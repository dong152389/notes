package com.dfd.consumer.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dfd.common.pojo.MqTopic;
import com.dfd.consumer.mapper.MqTopicMapper;
import com.dfd.consumer.service.MqTopicService;
import org.springframework.stereotype.Service;

/**
* @Author: Fengdong.Duan
* @Date: 2023/2/8 10:29
*/
@Service
public class MqTopicServiceImpl extends ServiceImpl<MqTopicMapper, MqTopic> implements MqTopicService {

}
