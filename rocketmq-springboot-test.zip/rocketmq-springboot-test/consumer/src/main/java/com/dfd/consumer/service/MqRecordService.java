package com.dfd.consumer.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.dfd.common.pojo.MqRecord;
    /**
* @Author: Fengdong.Duan
* @Date: 2023/2/8 10:25
*/
public interface MqRecordService extends IService<MqRecord>{


}
