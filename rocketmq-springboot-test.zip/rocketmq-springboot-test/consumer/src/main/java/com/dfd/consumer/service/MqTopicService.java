package com.dfd.consumer.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.dfd.common.pojo.MqTopic;

/**
 * @Author: Fengdong.Duan
 * @Date: 2023/2/8 10:29
 */
public interface MqTopicService extends IService<MqTopic> {


}
