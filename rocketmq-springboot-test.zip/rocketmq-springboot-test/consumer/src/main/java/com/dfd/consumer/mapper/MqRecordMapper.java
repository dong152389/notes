package com.dfd.consumer.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dfd.common.pojo.MqRecord;

/**
 * @Author: Fengdong.Duan
 * @Date: 2023/2/8 14:47
 */
public interface MqRecordMapper extends BaseMapper<MqRecord> {
}
